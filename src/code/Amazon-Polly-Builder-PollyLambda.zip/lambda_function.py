import json
import boto3
client = boto3.client('polly')

def build_response(status, body=None):
    return {
        'statusCode': status,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*'
        },
        'body': json.dumps(body) if body else None
    }

def build_not_found():
    return build_response(404, {'error': 'Not found'})

def lambda_handler(event, context):
    method = event['requestContext']['http']['method']
    path = event['requestContext']['http']['path']
    body = json.loads(event['body']) if 'body' in event else None
  
    if method == 'OPTIONS':
        return build_response(200)

    if path == '/':
        if method == 'POST':
            result = client.generate_presigned_url(
                ClientMethod='synthesize_speech',
                Params={'Engine':'standard', 'LanguageCode':'en-US', 'OutputFormat':'mp3', 'Text':body["text"],'TextType':'ssml', 'VoiceId':'Joanna'},
                ExpiresIn=3600,
                HttpMethod='get'
                )
            print(result)
            return build_response(200, result)
        
    return build_not_found()

